Name: Waseem Abu Leil 
Name: Muaz Abdeen  

Files:

1- README: this file
2- Answers.pdf: contains the plots, and the results of testing on whole test set, negation polarity set ad rare words set.
3- ex3.py: contains our implementation for the requested functions.
4- requirements.txt: contains the required libraries for the code.