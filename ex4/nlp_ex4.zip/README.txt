Name: Waseem Abu Leil 
Name: Muaz Abdeen  

Files:

1- README: this file
2- Answers.pdf: answers of theoretical part (Q2: Transition-based Parsing)
3- NLP_Ex4.py: contains our implementation for MST Parser.
4- RESULTS.txt: contains the results of the evaluation of out model.
5- requirements.txt: contains the required libraries for the code.